const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();

const allowedOrigins = ['http://localhost:5173']; 
app.use(cors({ origin: allowedOrigins }));

app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'UP', 
    uptime: process.uptime(),
    timestamp: new Date().toISOString() 
  });
});

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ["GET", "POST"]
  }
});

io.on('connection', (socket) => {
  console.log(`[INFO] Cliente conectado: ${socket.id}`);

  socket.on('join-room', (room) => {
    socket.join(room);
    console.log(`[INFO] Socket ${socket.id} se unió a la sala: ${room}`);
  });

  socket.on('draw-event', (payload) => {
    if (!payload || !payload.room || !payload.point || typeof payload.point.x !== 'number' || typeof payload.point.y !== 'number') {
      console.warn(`[WARN] Payload malformado rechazado del socket ${socket.id}:`, payload);
      return;
    }

    socket.to(payload.room).emit('blueprint-update', payload.point);
  });

  socket.on('dashboard-update', () => {
    socket.broadcast.emit('refresh-dashboard');
  });

  socket.on('disconnect', (reason) => {
    console.log(`[INFO] Cliente desconectado: ${socket.id} - Razón: ${reason}`);
  });
});

const PORT = 3001;
server.listen(PORT, () => {
  console.log(`[INFO] Servidor Socket.IO corriendo en http://localhost:${PORT}`);
});